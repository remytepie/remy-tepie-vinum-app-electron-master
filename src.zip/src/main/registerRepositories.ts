import { registerTodoRepository } from "./repositories/registerTodoRepository";

export function registerRepositories()
{
    registerTodoRepository();
}
